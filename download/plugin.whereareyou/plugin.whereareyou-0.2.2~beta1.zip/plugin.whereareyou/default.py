from resources.lib.whereareyou import Main

if ( __name__ == "__main__" ):
    Main()
