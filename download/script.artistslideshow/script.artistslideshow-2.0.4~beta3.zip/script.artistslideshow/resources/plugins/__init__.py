#__all__ = ['local', 'fanarttv', 'kodi', 'theaudiodb', 'htbackdrops', 'lastfm']
__all__ = ['local', 'theaudiodb', 'fanarttv', 'kodi', 'lastfm']