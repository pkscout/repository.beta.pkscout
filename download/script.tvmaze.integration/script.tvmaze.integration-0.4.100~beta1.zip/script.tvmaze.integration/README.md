# script.tvmaze.integration
Kodi service to integrate with TV Maze for show monitoring and tracking
