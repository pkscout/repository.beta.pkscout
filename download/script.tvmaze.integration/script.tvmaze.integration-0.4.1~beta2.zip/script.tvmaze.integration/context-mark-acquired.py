
from resources.lib.tvmi import tvmContext

if ( __name__ == "__main__" ):
    tvmContext( 'mark_acquired' )
