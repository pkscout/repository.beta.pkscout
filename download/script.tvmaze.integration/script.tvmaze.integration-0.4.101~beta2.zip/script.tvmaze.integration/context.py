
from resources.lib.tvmi import tvmContext
import sys

if ( __name__ == "__main__" ):
    tvmContext( sys.argv[1] )
