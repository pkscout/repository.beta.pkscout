# -*- coding: utf-8 -*-

from resources.lib.profiles import PROFILES

if ( __name__ == "__main__" ):
    PROFILES()
