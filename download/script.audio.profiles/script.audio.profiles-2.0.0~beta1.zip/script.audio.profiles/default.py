
from resources.lib.audioprofiles import apManual

if ( __name__ == "__main__" ):
    apManual()
