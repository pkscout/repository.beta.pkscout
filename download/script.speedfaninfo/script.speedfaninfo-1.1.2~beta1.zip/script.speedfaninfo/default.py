import resources.lib.spid as SpeedFan

if ( __name__ == "__main__" ):
    window = SpeedFan.Main()
