This Kodi plugin parses and displays information from the SpeedFan log. While this plugin works on any platform, SpeedFan only works on Windows, so it is optimally built for people using Kodi on Windows, but if you can point your non-Windows Kodi to the location of the Speedfan log, other versions will display the information from that log.

For more information and usage directions, please see:

<https://wiki.kodi.tv/index.php?title=Add-on:SpeedFan_Information_Display>